package com.example.prankcallapp

import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class SmsActivity : AppCompatActivity() {

    private lateinit var etTextMessage: EditText
    private lateinit var takeScreenShotButton: Button
    private var isKeyboardVisible = false
    private lateinit var sendMsgIcon : ImageView
    private lateinit var sendButton : Button
    private lateinit var receiveButton: Button
    private var isSendMsgIconClicked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms)

        etTextMessage = findViewById(R.id.et_write_message)
        takeScreenShotButton = findViewById(R.id.take_screenshot_tv_button)
        sendMsgIcon = findViewById(R.id.send_message_icon)
        sendButton = findViewById(R.id.send_button_above_icon)
        receiveButton = findViewById(R.id.receive_button_above_icon)

        sendMsgIcon.setOnClickListener {
            isSendMsgIconClicked = !isSendMsgIconClicked
            if (isSendMsgIconClicked) {
                sendButton.visibility = View.VISIBLE
                receiveButton.visibility = View.VISIBLE
            } else {
                sendButton.visibility = View.INVISIBLE
                receiveButton.visibility = View.INVISIBLE
            }
        }



        // Add a Global Layout Listener to detect keyboard visibility changes
        val rootView = findViewById<View>(android.R.id.content)
        rootView.viewTreeObserver.addOnGlobalLayoutListener {
            val rect = Rect()
            rootView.getWindowVisibleDisplayFrame(rect)
            val screenHeight = rootView.height
            val keypadHeight = screenHeight - rect.bottom
            val keyboardCurrentlyVisible = keypadHeight > screenHeight * 0.15

            if (keyboardCurrentlyVisible && !isKeyboardVisible) {
                isKeyboardVisible = true
                // Do nothing, buttons are already visible
            } else if (!keyboardCurrentlyVisible && isKeyboardVisible) {
                isKeyboardVisible = false
                takeScreenShotButton.visibility = View.VISIBLE
                Log.d("SmsActivity", "Keyboard hidden")
            }
        }
    }

    @Deprecated("Deprecated in Java",
        ReplaceWith("super.onBackPressed()", "androidx.appcompat.app.AppCompatActivity")
    )
    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()

    }
}



